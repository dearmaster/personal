package com.master.concept.hashmap;

import java.util.Hashtable;

public class HashTableHashMapNullKeyValue {

    public static void main(String[] args) {
//        String key = null;
//        System.out.println(key.hashCode());
        System.out.println(-1 >> 1);
        System.out.println(-1 >>> 1);
        System.out.println(Integer.MAX_VALUE);

        System.out.println(Integer.MAX_VALUE << 1);
        System.out.println(Integer.MAX_VALUE >>> 1);

        Hashtable hashtable = new Hashtable();
//        hashtable.put(123, null);
//        hashtable.put(null, 123);
    }

}