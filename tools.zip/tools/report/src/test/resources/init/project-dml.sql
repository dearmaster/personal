insert into T_BATCH_TEST_USER(id, username) values (1001, 'lucy');
insert into T_BATCH_TEST_USER(id, username) values (1002, 'lily');
insert into T_BATCH_TEST_USER(id, username) values (1003, 'jim');
insert into T_BATCH_TEST_USER(id, username) values (1004, 'kevin');
insert into T_BATCH_TEST_USER(id, username) values (1005, 'jacky');
insert into T_BATCH_TEST_USER(id, username) values (1006, 'poly');
insert into T_BATCH_TEST_USER(id, username) values (1007, 'top');
insert into T_BATCH_TEST_USER(id, username) values (1008, 'michael');