package com.master.transaction.jdbc;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class AbstractJdbcDaoSupport extends JdbcDaoSupport {
}