package com.master.transaction.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.springframework.jdbc.core.RowMapper;

public class UserDaoImpl extends AbstractJdbcDaoSupport implements UserDao {
	
	private static final String USER_BALANCE_DEPOSIT_SQL = "update user_balance_tbl set balance = balance + ? where username = ?";
	private static final String USER_BALANCE_WITHDRAW_SQL = "update user_balance_tbl set balance = balance - ? where username = ?";
	private static final String USER_BALANCE_QUERY_SQL = "select * from user_balance_tbl where username = ?";
	
	@Override
	public void deposit(User user, double amount) {
		this.getJdbcTemplate().update(USER_BALANCE_DEPOSIT_SQL, new Object[]{amount, user.getUsername()}, new Object[]{Types.DOUBLE, Types.VARCHAR});
	}

	@Override
	public void withdraw(User user, double amount) {
		this.getJdbcTemplate().update(USER_BALANCE_WITHDRAW_SQL, new Object[]{amount, user.getUsername()}, new Object[]{Types.DOUBLE, Types.VARCHAR});
	}

	@Override
	public Double getBalance(User user) {
		this.getJdbcTemplate().query(USER_BALANCE_QUERY_SQL, new RowMapper<Double>() {

			@Override
			public Double mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getDouble("balance");
			}
			
		}, user.getUsername());
		return null;
	}

}
