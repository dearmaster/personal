package com.master.transaction.jdbc;

public class UserServiceImpl implements UserService {

	@Override
	public void transfer(User userFrom, User userTo, double amount) {
		withdraw(userFrom, amount);
		deposit(userTo, amount);
	}
	
	private void withdraw(User user, double amount) {
		
	}
	
	private void deposit(User user, double amount) {
		
	}

}