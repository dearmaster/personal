package com.master.transaction.jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public void transfer(User userFrom, User userTo, double amount) {
		withdraw(userFrom, amount);
		deposit(userTo, amount);
	}
	
	private void withdraw(User user, double amount) {
		userDao.withdraw(user, amount);
	}
	
	private void deposit(User user, double amount) {
		userDao.deposit(user, amount);
	}

}