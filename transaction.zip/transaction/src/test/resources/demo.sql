create table user_balance_tbl(username varchar(20) not null, balance float);

drop table user_balance_tbl;


select * from user_balance_tbl;